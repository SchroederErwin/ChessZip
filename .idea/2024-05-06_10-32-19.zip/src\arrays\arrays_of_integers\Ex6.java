package arrays.arrays_of_integers;

public class Ex6 {
    public static void main(String[] args) {
        int[] input = new int[]{100,4,200,1,3,2,0,1};
        int[] input2 = new int[]{0,3,7,2,5,8,4,6,0,1,1}; //--> 0,1,2,3,4
        int[] output = new int[input.length];
        int outputIndex = 0;
        boolean isInOutput;
        for (int i = 0; i < input.length; i++) {

            for (int j = 0; j < input2.length; j++) {
                if (input[i] == input2[j]) {                //is intersection
                    isInOutput = false;
                    for (int k = 0; k < outputIndex; k++) { //check if already inside output
                        if (input[i] == output[k]) {
                            isInOutput = true;
                            break;
                        }
                    }
                    if (!isInOutput) {
                        output[outputIndex++] = input[i];
                    }
                    break; //to not do more work than necessary --> already found that it intersects
                            // and prevent duplicates of 2nd array (out of bounds possible on output)
                }
            }
        }

        //for loop till outputIndex-1 to not include all leftover 0's from instantiating output
        for (int i = 0; i < outputIndex; i++) {
            System.out.print(output[i] + " ");
        }
    }
}
