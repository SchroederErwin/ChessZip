package strings.characters_and_strings;

public class Ex1 {
    public static void main(String[] args) {
        char[] input = new char[]{'A', 'W', ' ', 'A', 'c', 'a', 'd', 'e', 'm', 'y'};
       for (int i = input.length-1; i>=0 ; i--) {
           System.out.print(input[i]);
       }
    }
}
