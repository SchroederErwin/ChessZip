package arrays.arrays_of_integers;

public class Ex4 {
    public static void main(String[] args) {
        int[] input = new int[]{1,2,3,4,5,6,7,8,9,10};
        for (int i = 0; i < input.length - 1; i++) {
            for (int j = 0; j < input.length - i - 1; j++) {
                if (input[j] < input[j + 1]) {
                    int tmp = input[j];
                    input[j] = input[j + 1];
                    input[j + 1] = tmp;
                }
            }
        }
        for (int num : input) {
            System.out.print(num + " ");
        }
    }
}
