package strings.stringbuilder;

public class Ex2 {
    public static void main(String[] args) {
        StringBuilder table = new StringBuilder();
        table.append("<table>\n");
        for (int i = 1; i < 10; i++) {
            if (i%2 == 0){ //even
                table.append("\t<tr style=\"background: darkgoldenrod\">\n" +
                        "\t\t<td>Row " + i +"</td>\n" +
                        "\t\t<td>xxxx</td>\n" +
                        "\t</tr>\n");
            } else { //odd
                table.append("\t<tr style=\"background: aqua\">\n" +
                        "\t\t<td>Row " + i + "</td>\n" +
                        "\t\t<td>xxxx</td>\n" +
                        "\t</tr>\n");
            }
        }
        table.append("</table>\n");
        System.out.println(table);
    }
}
