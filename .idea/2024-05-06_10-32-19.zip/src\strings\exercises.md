# Strings (Exercises)
***
## Characters and Strings
1. Write a program which prints the following character array with a reverse for loop.
   `char[] name = {'A', 'W', ' ', 'A', 'c', 'a', 'd', 'e', 'm', 'y'};`
2. Write a program that outputs every second character of the array. Output should be `"A cdm"`.

   *Hint: Use a single loop, don’t use modulo*
3. Write a program which converts the array from exercise 1 into a String and prints it out.
4. Write a program which converts a String into a char array. Print the array.
5. Write a program to convert the String `"1, 2, 4, 9, 8, 7, 6, 4, 1"` into an array of integers. Print the array.

   *Hint: Check out the String method **split()**.*
***
## ASCII Table
1. Write a program which prints the ASCII table on screen. Research, what the ASCII table is and how to format it.

Hints:
- Which characters are part of the ASCII table? 0-127 oder 0-255?
- Read more about ASCII: <https://en.wikipedia.org/wiki/ASCII>

### Bonus exercise
Also print the hexadecimal value of ever character.
***
## Input validation
We typically do input verification against various rules and conditions when we receive data from the user.

1. Write an application that returns `"Input Error"` if the input string is too long (longer than 10 characters), 
   or `"OK"` if the input complies with the rules.

Example:

`Input: ShortStr
Output: OK`

`Input: ThisIsAVeryLongTest
Output: Input Error`

2. Implement the following validation rules. Write `"OK"` on the console when the rule is met. Otherwise `"Input Error"`.

***Important**: Do the validation one after the other (no nesting).*

* The length of the input string must be greater than 5.
* The length of the input string must be between 4-8 characters.
* Input string must start with 2 numeric characters. *Hint: Use **Character.isDigit()***</p>
* String must contain "chen", such as "München".
* String must end with a colon.
* All characters in the input are uppercase.
* The input string must contain the characters '(' and ')'. And the ')' must come after the '('.

*Hint*:
* Test your code extensively. Make sure it also works with empty strings or strings with only one character.
* More examples for strings which might cause problems can be found in [”The Big List of Naughty Strings is a list of strings which have a high probability of causing issues when used as user-input data.”](https://github.com/minimaxir/big-list-of-naughty-strings)
***
## String Manipulation
In the following exercises you need to clean the input by removing certain parts of the provided string.

Every step is independent and can be implemented separately.

1. When the input starts with „+49“, remove that part. For example „+4989123456“ becomes „89123456“.
2. Remove all dots '.' from the input, e.g. "127.0.0.1" should become 127001
3. String of numbers my contain negative numbers. E.g. "123, 45, -34.231, 0, -1, -12312, 12312, 23423".</p><p></p><p>Replace all negative values with null (“0”). A new, comma separated string should be created, e.g. "123,45,0,231,0,0,0,12312,23423".</p><p></p><p>Also, all spaces should be removed, if any.
4. If there is no dot at the end, add it.

Use the String methods `split` and `trim`.
***
## StringBuilder
### Part 1
In many applications, Java is used to generate HTML. Generate a complete HTML table with a StringBuilder. Print the result.
````html
<table>
    <tr>
        <td>Row 1</td>
        <td>xxxx</td>
    </tr>
    <tr>
        <td>Row 2</td>
        <td>xxxx</td>
    </tr>
    <tr>
        <td>Row 3</td>
        <td>xxxx</td>
    </tr>
    <!--...-->
    <tr>
        <td>Row 9</td>
        <td>xxxx</td>
    </tr>
</table>
````
Generate a table with 10 rows. The first column (`<td>`) should include the line number. Use the `StringBuilder` for this task.

### Part 2
Change the code from part 1, so it uses a different background color for even rows.
````html
<table>
    <tr style="background: aqua">
        <td>Row 1</td>
        <td>xxxx</td>
    </tr>
    <tr style="background: darkgoldenrod">
        <td>Row 2</td>
        <td>xxxx</td>
    </tr>
    <tr style="background: aqua">
        <td>Row 3</td>
        <td>xxxx</td>
    </tr>
    <tr style="background: darkgoldenrod">
        <td>Row 4</td>
        <td>xxxx</td>
    </tr>
    <!--...-->
</table>
````
***
## Receipt

In this exercise, you are writing a console application which asks the user for details to a product and prints a receipt for the purchase.
We ask for the product name, price, amount and whether it is food or not. When it is food, the tax is 7%, otherwise 19%.

Example:
````
Enter the product name: AAA Batteries
Price per unit: 5
Quantity bought: 4
Food? (y / n): n
--- RECEIPT ---
Product: AAA Batteries
Price per unit: 5
Quantity bought: 4
Total amount to pay, excluding tax: 20
Total amount to pay, including tax: 23,80 Euro
Of which is tax: 3,80 Euro
----------------
````
Build the whole receipt as one `String` using `StringBuilder` and print it out.

