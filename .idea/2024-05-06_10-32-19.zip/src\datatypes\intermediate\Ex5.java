package datatypes.intermediate;

public class Ex5 {
    public static void main(String[] args) {
        int num = 56; //scanner after                   1 1 1 0 0 0
        System.out.println(Integer.toBinaryString(num));

        //alternative
        StringBuilder sb = new StringBuilder(); //111 0 0 0
        while (num > 0) { //works only for positive integers
            sb.insert(0,num%2);
            num /= 2;
        }

        System.out.println(sb);
    }

}
