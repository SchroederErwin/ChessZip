package strings;

import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;

public class TemplateStrings {
    public static void main(String[] args) {
        // String vs. StringBuilder

        ZonedDateTime now = ZonedDateTime.now();  // start the stopwatch
        String str = "";
        for (int i = 0; i < 200; i++) {
            str += "!";
        }
        long milliseconds = now.until(ZonedDateTime.now(), ChronoUnit.MILLIS);  // stop the stopwatch
        System.out.println("String append: " + milliseconds);


        now = ZonedDateTime.now();  // start the stopwatch
        StringBuilder sb = new StringBuilder("");
        for (int i = 0; i < 200; i++) {
            sb.append("!");
        }
        milliseconds = now.until(ZonedDateTime.now(), ChronoUnit.MILLIS);  // stop the stopwatch
        System.out.println("String Builder: " + milliseconds);

    }
}
