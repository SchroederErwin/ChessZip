package arrays.isbn_validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Ex1 {
    public static void main(String[] args) {
        int[] isbn1 = new int[]{9, 7, 8, 0, 3, 0, 6, 4, 0, 6, 1, 5};
        int checkSum = calculateChecksumISBN13(isbn1);
        System.out.println(checkSum);
        String isbn2 = "978-3-16-148410-0";
        System.out.printf("%s is %s", isbn2, isValidISBN13(isbn2) ? "valid" : "not valid");
    }

    public static int calculateChecksumISBN13(int[] digits) {
        int checkSum = 0;
        for (int i = 0; i < 12; i++) { //alternate between x1+3x2+x3+...
            if (i % 2 == 0) {
                checkSum += digits[i];
            } else {
                checkSum += 3 * digits[i];
            }
        }
        checkSum = 10 - checkSum % 10;
        return (checkSum < 9) ? checkSum : 0;
    }

    public static boolean isValidISBN13(String isbn) {
        String[] isbnArrayString = new String[13];
        Pattern pattern = Pattern.compile("\\d");
        Matcher matcher = pattern.matcher(isbn);
        int index = 0;
        while (matcher.find()) {
            isbnArrayString[index++] = matcher.group();
        }
        int[] isbnArrayInt = new int[13];
        for (int i = 0; i < isbnArrayString.length; i++) {
            isbnArrayInt[i] = Integer.parseInt(isbnArrayString[i]);
        }
        return (isbnArrayInt[12] == calculateChecksumISBN13(isbnArrayInt));
    }
}
