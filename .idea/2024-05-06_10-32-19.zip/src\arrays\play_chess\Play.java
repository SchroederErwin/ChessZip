package arrays.play_chess;

import java.util.Scanner;

public class Play {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Game board = new Game();
        String input = "";
        while (!input.equals("quit") && !board.isGameOver) {
            board.status();
            do {
                System.out.println("Turn: " + (board.turn.equals("W") ? "White" : "Black"));
                System.out.print("Please enter your move: ");
                input = sc.nextLine();
            } while (!board.makeMove(input));

        }
        //win message
        if (board.isGameOver){
            board.switchTurn();
            System.out.println();
            System.out.println((board.turn.equals("W") ? "White" : "Black") + " has won!");
        }
        System.out.println("Thank you for playing");


//        board.status();
//        board.makeMove("E2-E4");
//        System.out.println();
//        board.status();
//        char c = '\u2654';
//        char d = '\u265A';
//        System.out.println(c+ " " +d);
    }

    // To-Do
    // pawn promotion
    // alternative version with unicode symbols for diplay
    // check if one is attacked by for looping for the piece if its valid from any piece to have your piece as goal and break, do for all my pieces, check how to colour
    // but do it as if its enemy turn
}
