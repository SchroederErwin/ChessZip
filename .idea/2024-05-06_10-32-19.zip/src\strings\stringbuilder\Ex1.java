package strings.stringbuilder;

public class Ex1 {
    public static void main(String[] args) {
        StringBuilder table = new StringBuilder();
        table.append("<table>\n");
        for (int i = 1; i < 10; i++) {
            table.append("\t<tr>\n" +
                    "\t\t<td>Row " + i +"</td>\n" +
                    "\t\t<td>xxxx</td>\n" +
                    "\t</tr>\n");
        }
        table.append("</table>\n");
        System.out.println(table);
    }
}
