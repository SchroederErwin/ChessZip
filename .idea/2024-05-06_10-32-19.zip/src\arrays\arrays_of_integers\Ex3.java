package arrays.arrays_of_integers;

public class Ex3 {
    public static void main(String[] args) {
        int[] input = new int[]{1,2,3,4,0,6,3,3,2,1,2,5,0};
        int[] output = new int[input.length];
        int j = 0; //output index counter //indirect "length" (not capacity)
        for (int i = 0; i < input.length; i++) {
            boolean isDuplicate = false;
            //check if current index value if already in output
            for (int k = 0;k<j;k++){
                if(input[i] == output[k]){
                    isDuplicate = true;
                    break;
                }
            }
            //add if not duplicate
            if(!isDuplicate){
                output[j] = input[i];
                j++;
            }
        }
        //still print empty 0's at the end -    fixed with ArrayList(Dynamic Array)
        //                                      or duplicating to j-1
        for (int number: output){
            System.out.print(number + " ");
        }
    }
}
