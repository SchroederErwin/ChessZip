package strings.string_manipulation;

public class Ex1 {
    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter a String to edit: ");
//        String input = sc.nextLine();
        String input = "123,45,0,231,0,0,0,12312,23423";
        telephoneNumberCheck(input);
        dotRemover(input);
        negativeRemover(input);
        input = (input.endsWith(".") ? input : input.concat("."));

    }

    private static void dotRemover(String input) {
        if (input.contains(".")){
            input = input.replace(".","");
            System.out.println(input);
        }
    }

    private static void telephoneNumberCheck(String input) {
        if (input.length()>2 && input.substring(0,3).equals("+49")){ //input.startsWith("+49")
            input = input.substring(3, input.length());
            System.out.println(input);
        }
    }

    private static void negativeRemover(String input) {
        String[] numbers = input.split("\\s?[,\\.]");
        String output = "";
        for (String number : numbers) {
            if (Integer.parseInt(number)>0){
                output = output.concat(number+", ");
            } else {
                output = output.concat("0, ");
            }

        }
        System.out.println(output + "\b\b");

    }
}
