package datatypes;

import java.math.BigInteger;
import java.sql.SQLOutput;

public class TemplateDatatypes {
    public static void main(String[] args) {
        // Experimente mit primitive Datentypen (NICHT Referenztypen)
        // Overflow
        // --------
        // Erklärungen
        // Integer = 4 Byte = 4 * 8 Bits = 32 mal 1 und 0
        int number = Integer.MAX_VALUE;  // maximaler Integer: 2^31 - 1
        int min_number = Integer.MIN_VALUE;

        int nochne_zahl = 2147483647 + 1;

        System.out.println(number + 1); // das gibt einen Overflow
        System.out.println(min_number - 1); // das gibt einen Underflow

        // Besondere Zahlen
        // ----------------
        int binaryNumber = 0b1001;  // dezimal = 9
        System.out.println("Binary: " + binaryNumber);
        int hexadecimalNumber = 0xAB;
        System.out.println("Hex: " + hexadecimalNumber); // dezimal = 171
        int octalNumber = 011;
        System.out.println("Oct: " + octalNumber);

        // Besondere Kommazahlen
        // ---------------------
        double accurateNumber;
        accurateNumber = 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1;
        System.out.println("Double accuracy: " + accurateNumber);
        System.out.println(100_000_000f - 1f);

        // Chars
        // -----
        // chars haben die ASCII Tabelle als Nummerierungsbasis
        char letter = 'A';
        char new_letter = (char) (letter + 5); // explicit cast!

        System.out.println(letter + 3); // implicit cast to int
        System.out.println("Char adding: " + new_letter);  // result: F

        // Umwandlung von Groß in Kleinbuchstaben
        // 1. + 32
        System.out.println((char)(letter + 32));
        // 2. ??
        int abstand =  Math.abs('E' - 'e'); // 32!
        System.out.println((char)(letter + abstand));


        //////////////////////////////////////////////////////////////
        // Thorstens BigDecimal Experiment
        // BigDecimal = Referenztyp
        // hier gibts kein Problem mit dem Overflow wie oben
        BigInteger bigInteger = new BigInteger("2147483648");
        System.out.println("BigInteger Exkurs: " + bigInteger);
        //////////////////////////////////////////////////////////////

        // Casting & Wrapper classes
        // Implicit casts: Automatisch - "small to big"
        short shortValue = 123;
        int intValue = shortValue;

        // Explicit casts: Muss ich selbst machen - "big to small"
        double valuePi = 3.141;
        float floatPi = (float) valuePi;

        // "weird" casts
        int doubleResult = (int) (intValue + 1.934f);
        System.out.println(doubleResult); // wird nicht gerundet - sondern "abgehackt"

        // Wrapper classes: Autoboxing / -unboxing
        // Wir brauchen die Wrapper Klassen spätestens bei den Collections 😁
        int truth = 42;
        Integer tInteger = truth;
        int reconvertedTruth = tInteger;


        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        // Mededes NaN & Infinite Fragen (Anwendung nicht bei primitiven Datentypen - nur bei Wrapper Klassen!)
        double nan = Double.NaN;
        double positiveInfinity = Double.POSITIVE_INFINITY;
        double negativeInfinity = Double.NEGATIVE_INFINITY;

        System.out.println("NaN: " + nan);
        System.out.println("Positive Infinity: " + positiveInfinity);
        System.out.println("Negative Infinity: " + negativeInfinity);

        // Operations mit NaN
        double result1 = nan + 5;
        System.out.println("NaN + 5: " + result1); // NaN

        // Operations mit Infinity
        double result2 = positiveInfinity * 10;
        double result3 = negativeInfinity / 2;

        System.out.println("Infinity * 10: " + result2); // Infinity
        System.out.println("-Infinity / 2: " + result3); // -Infinity
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
    }
}
