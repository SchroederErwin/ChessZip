package strings.characters_and_strings;

public class Ex3 {
    public static void main(String[] args) {
        char[] input = new char[]{'A', 'W', ' ', 'A', 'c', 'a', 'd', 'e', 'm', 'y'};
        StringBuilder output = new StringBuilder();
        for (char c : input) {
            output.append(c);
        }
        System.out.println(output);
    }
}

