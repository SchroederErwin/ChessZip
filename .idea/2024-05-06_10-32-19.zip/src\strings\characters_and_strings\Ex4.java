package strings.characters_and_strings;

public class Ex4 {
    public static void main(String[] args) {
        String input = "AW Academy";
        char[] output = new char[input.length()];
        for (int i = 0; i < input.length(); i++) {
            output[i] = input.charAt(i);
        }

        for (char c : output){
            System.out.print("['" + c + "'], ");
        }
        System.out.print("\b\b");
    }
}
