package datatypes.basic;

public class Exercises1_3 {
    public static void main(String[] args) {
        System.out.println("Basic:");
        System.out.println("---------------");
        System.out.println("Basic 1i:");

        int i = 42;
        System.out.println(i);
        System.out.println(i++);
        System.out.println(i);
        System.out.println(++i);
        System.out.println(i);
        System.out.println("i++ increases after it was used and ++i before its used. Therefore the 2nd i is only increased when printed in the third row, while the fourth i is already increased when printed.");

        System.out.println("---------------");
        System.out.println("Basic 1ii:");
        int j = 42;
        int k = j++ + ++j;
        System.out.println(k);
        System.out.println("das erste j ist 42 und das zweite j 44. Gleiche Erklärung wie oben.");


        System.out.println("---------------");
        System.out.println("Basic 2:");
        int m = 43;
        m += 100;
        m -= 24;
        m *= 2;
        m /= 5;
        System.out.println(m);

        System.out.println("---------------");
        System.out.println("Basic 3i:");

        int[] even = new int[22];
        int[] odd = new int [22];
        int evenCounter = 0;
        int oddCounter = 0;
        for(int n = 0;n<=43;n++){
            if ((n%2)==1){
                odd[oddCounter]=n;
                oddCounter++;
            } else {
                even[evenCounter]=n;
                evenCounter++;
            }
        }
        System.out.println("Even numbers: ");
        for (int number : even){
            System.out.print(number + " ");
        }
        System.out.println("\nOdd numbers: ");
        for (int number : odd){
            System.out.print(number + " ");
        }

        System.out.println("---------------");
        System.out.println("Basic 3ii:");
        System.out.println("-4,-3,-2,-1,0,1,2,3,4");

    }
}
