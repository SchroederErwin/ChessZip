package datatypes.intermediate;

public class Ex6 {
    public static void main(String[] args) {
        String test = "Hello World";
        int vowels = 0;
        for (int i =0; i<test.length(); i++) {
            if (test.charAt(i) == 'a' || test.charAt(i) == 'e' || test.charAt(i) == 'i' || test.charAt(i) == 'o'|| test.charAt(i) == 'u' ) vowels++;
        }

        System.out.println(vowels);
    }
}
