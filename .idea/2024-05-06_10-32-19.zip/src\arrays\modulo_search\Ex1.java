package arrays.modulo_search;

public class Ex1 {
    public static void main(String[] args) {
        int[] input = new int[]{1, 4, 5, 7, 20000, -511, 100, -200, 400};
        int[] temp = new int[input.length]; //temporary array to get the length of results and later instantiate results with right length
        int[] result;

        int tempIndex = 0;                  //length tracker
        for (int number : input) {
            if (number%2 ==0){              //only add even numbers
                temp[tempIndex++] = number;
            }
        }
        result = new int[tempIndex];        //instantiate with correct length
        for (int i = 0; i < tempIndex; i++) {
            result[i] = temp[i];            //copy from temp
        }


        for (int item : result) {
            System.out.println(item);
        }
    }
}
