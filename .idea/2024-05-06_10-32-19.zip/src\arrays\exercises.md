# Arrays (Exercises)
![](https://miro.medium.com/v2/resize:fit:640/format:webp/1*Egop4mNfIJ3SIOMBzxHKXQ.jpeg)
![](https://res.cloudinary.com/practicaldev/image/fetch/s--7QY1RFlt--/c_limit%2Cf_auto%2Cfl_progressive%2Cq_auto%2Cw_880/https://dev-to-uploads.s3.amazonaws.com/i/71rzvi7bu86foex8a1z1.png)

## Sum, maximum and minimum - known from the prestudies ⭐
1. Write a program, which determines the sum, maximum and minimum value of this array using a for loop.
````java
int[] input = new int[]{1, 4, 5, 7, 20000, -511, 100, -200, 400};
````
 
2. Change the code to use a for-each loop instead.
````java
for (int item: input) {...}
````

## 🔢 Arrays of integers ⭐⭐
Implement the following ideas within one class. Use one method for each subtask:
1. find the average of elements ("median") in an array of integers.
2. rotate an array of integers by a given number of positions. E.g. `{1, 2, 3, 4 ,5}` rotated by 2 is `{5, 4, 1, 2, 3}`
3. remove duplicates from an array of integers.
4. sort an array of integers in descending order.
5. find the longest consecutive sequence of elements in an array of integers. 
6. find the intersection of two arrays of integers.

## 🔍 Modulo Search ⭐
Find all even numbers in one array and write them into another array. The resulting array should only be as long as the number of results.
````java
int[] input = new int[]{1, 4, 5, 7, 20000, -511, 100, -200, 400};
int[] result;

// TODO: put even numbers of input into result

for (int item : result) {
    System.out.println(item);
}
````

## ✖ Matrix Multiplication ⭐⭐
Implement a method to [multiply two matrices](https://en.wikipedia.org/wiki/Matrix_multiplication) (represented as two-dimensional int arrays). Use the following main-method &
implement the `printMatrix` method first:
````java
public static void main(String[] args) {
    int[][] m1 = { {3, 2, 1}, {1, 0, 2} };
    int[][] m2 = { {1, 2}, {0, 1}, {4, 0} };

    System.out.println("M1:");
    printMatrice(m1);
    System.out.println("M2:");
    printMatrice(m2);
    int[][] result = matrixMultiply(m1, m2);
    System.out.println("M1 x M2 = ");
    printMatrice(result);
}
````
## ♾ Roman Number Conversion ⭐⭐
Create a method `intToRoman(int num)` which converts an Integer value between 1 and 3999 to its Roman Number representation.
You may use the following `main` method:
````java
public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.print("Enter an integer between 1 and 3999: ");
    int num = scanner.nextInt();
    String romanNum = intToRoman(num);
    System.out.println(num + " in Roman numerals is " + romanNum);
}
````
_Hint: within your method, the following two arrays may be helpful:_
````java
String[] romanSymbols = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
int[] romanValues = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
````

## 📔 ISBN Validation ⭐⭐
You probably know about the [International Standard Book Number (ISBN)](https://en.wikipedia.org/wiki/ISBN) which is used to identify books. There are two 
variants of the ISBN:
* ISBN-10: consists of 10 digits
* ISBN-13: consists of 13 digits

In most of the books in Germany the variant ISBN-13 is used. 

Create a class with a `main`-method, which should call two different methods (implemented by you):

1. `public static int calculateChecksumISBN13(int[] digits) { ... }` 

    This method shall calculate the 13th digit (which is the checksum) for 12 digits that are passed as parameter array `digits`.
    The checksum shall be returned
2. `public static boolean isValidISBN13(String isbn) { ... }`

    This method shall check a String parameter `isbn` if it is a valid ISBN13 number. Therefore you'll need to convert the String
    into an int-Array, pass the first twelve elements of this array to the `calculateChecksumISBN13()` method and compare the result
    to the 13th number. Try to be as error tolerant as possible when converting the String.

## 💰 IBAN Validation ⭐⭐⭐ 
Validate a given String if it represents a German IBAN. Following criteria have to fulfilled:
* String starting with "DE"
* Length: 22
* Modulo 97 validation rule fulfilled (see: https://de.wikipedia.org/wiki/Internationale_Bankkontonummer#Prüfsumme)

You may use the following main method to test your implementation:
````java
public static void main(String[] args) {
    String testIBANValid   = "DE23 6005 0101 1111 2222 33"; // "DE65 100 400 600 100 400 600";
    String testIBANInvalid = "DE12 345 678 910 234 567 89";

    System.out.println(testIBANInvalid + " is valid? " + validateIBAN(testIBANInvalid));
    System.out.println(testIBANValid + " is valid? " + validateIBAN(testIBANValid));
}
````

## ♟ Let's play chess ⭐⭐⭐
For this exercise (with friendly support of chatGPT) you will need to know basics about the [chess notation](https://en.wikipedia.org/wiki/Algebraic_notation_(chess))
1. Initialize a chess board as a 2D array of size 8x8, with each element representing a square on the board. Use "B" to represent black pieces and "W" to represent white pieces. Place the pieces in their initial positions.
2. Print the current state of a chess board, with each piece represented by its corresponding symbol.
3. Check if a move is valid on a chess board. Assume that the move is given in standard chess notation (e.g. "e2-e4" for moving a white pawn from square e2 to square e4).
4. Check if a given square on a chess board is under attack by a certain color. Assume that the board is in its current state and the color of the attacking pieces is specified.
5. Generates a list of all possible legal moves for a given color on a chess board. Return the list as an array of strings in standard chess notation.
6. Calculate the value of a chess board position using a simple scoring system. Assign a point value to each piece and use it to evaluate the board state.
7. Generate a random legal move for a given color on a chess board.
8. Implement the chess game logic, allowing two human players to play against each other on the console.
