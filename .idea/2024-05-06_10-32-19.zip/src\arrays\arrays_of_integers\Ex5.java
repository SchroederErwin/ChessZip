package arrays.arrays_of_integers;

import java.sql.SQLOutput;

public class Ex5 {
    public static void main(String[] args) {
        int[] input = new int[]{100,4,200,1,3,2}; //->4
        int[] input2 = new int[]{0,3,7,2,5,8,4,6,0,1}; //->9
        int[] output = longestConsecutiveSequence(input);
        int[] output2 = longestConsecutiveSequence(input2);
        System.out.println("Array No. 1: ");
        displayArray(input);
        System.out.println("Longest consecutive sequence in Array No. 1: ");
        displayArray(output);
        System.out.println("Array No. 2: ");
        displayArray(input2);
        System.out.println("Longest consecutive sequence in Array No. 2: ");
        displayArray(output2);


    }

    /**
     * Prints all components of an integer array
     * @param output
     */
    private static void displayArray(int[] output) {
        for (int num : output){
            System.out.print(num + " ");
        }
        System.out.println("\n");
    }

    /**
     * first (when sorted in an ascending order) longest consecutive sequence of numbers
     * @param input integer array
     * @return
     */
    private static int[] longestConsecutiveSequence(int[] input) {
        int[] copy = bubbleSort(input);

        int currStreak = 1;
        int maxStreak = 1;
        int maxLastIndex = 0;
        for (int i = 0; i < copy.length-1; i++) { //don't go the last element
            if (copy[i]+1 == copy[i+1]){
                currStreak++;
            }
            if (currStreak > maxStreak){
                maxStreak = currStreak;
                maxLastIndex = i+1;
            }

        }
        int[] output = new int[maxStreak];
        for (int i = 0; i < maxStreak; i++) {
            output[i] = copy[i+maxLastIndex-maxStreak+1];
        }
        return output;
    }

    /**
     * sorts copy of integer array out-of-place in ascending order
     * @param input integer array which get sorted
     */
    private static int[] bubbleSort(int[] input) {
        int[] copy = new int[input.length];
        for (int i = 0; i < input.length; i++) {
            copy[i] = input[i];
        }

        for (int i = 0; i < copy.length - 1; i++) {
            for (int j = 0; j < copy.length - i - 1; j++) {
                if (copy[j] > copy[j + 1]) {
                    int tmp = copy[j];
                    copy[j] = copy[j + 1];
                    copy[j + 1] = tmp;
                }
            }
        }
        return copy;
    }
}
