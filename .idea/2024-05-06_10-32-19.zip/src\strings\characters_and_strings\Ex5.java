package strings.characters_and_strings;

import java.util.ArrayList;

public class Ex5 {
    public static void main(String[] args) {
        String input = "1, 2, 4, 9, 8, 7, 6, 4, 1";
        String[] split = input.split(", ");
        ArrayList<Integer> output = new ArrayList<>();
        for (int i = 0; i < split.length; i++) {
            output.add(Integer.parseInt(split[i]));
        }
        for (int i : output){
            System.out.println(i);
        }

    }
}
