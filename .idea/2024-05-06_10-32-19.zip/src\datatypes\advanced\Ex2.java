package datatypes.advanced;

public class Ex2 {
    public static void main(String[] args) {
        String example = "attacking tonight";
        boolean isInputUp = example.equals(example.toUpperCase()); //check whether 65 or 97 should be used. Doesn't work for mixed text.
        StringBuilder output = new StringBuilder();
        String offset = "OCULORHINOLARINGOLOGY";
        int i = 0;
        for (char c: example.toCharArray()){
            if (c != ' '){
            output.append(shift(c,(offset.charAt(i++%offset.length())-65)%26,isInputUp)); //mod for repeated key
            }
            else{
                output.append(' ');
            }
        }


        System.out.println(output);
    }
    

    public static char shift(char input,int offset,boolean isUp) {
        int asciiOffset;
        asciiOffset = (isUp ? 65 : 97);
        input = (char)((input-asciiOffset+offset)%26+asciiOffset);
        return input;
    }
}
