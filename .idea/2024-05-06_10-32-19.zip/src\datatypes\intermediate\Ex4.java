package datatypes.intermediate;

import java.util.Scanner;

public class Ex4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter an integer: ");
        int num = sc.nextInt();
        System.out.println("Enter another integer: ");
        int num2 = sc.nextInt();
        System.out.println("Sum: " + (num + num2));
        System.out.println("Difference: " + (num - num2));
        System.out.println("Product: " + (num * num2));
        System.out.println("Quotient: " + ((double)num / num2));
        for (int i = num; i > 0; i--) { //go backwards to find highest divisor and break after;
            if (num % i == 0 && num2 % i == 0) { //both divisible by current i
                System.out.println("gcd: " + i);
                break;
            }
        }
    }
}
