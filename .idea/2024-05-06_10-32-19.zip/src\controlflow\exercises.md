# Control Flow (Exercises)
*The following exercises focus on the useage of the switch construct*


## Coloring a number
1. Write a program, which accepts a number as input and outputs one of the following colors:

   ![](images/colorswitch1.png)

   *Use the switch statement. For invalid input, print a message.*

2. Change the code from the previous exercise to accept a character instead of a number:

   ![](images/colorswitch2.png)

   *Use the switch statement. For invalid input, print a message.*

## Fall through
1. What is the output of this code?
   ````java
   char input = 'b';
   switch (input) {
        case 'a':
            System.out.println("Airplane");
            break;
        case 'b':
            System.out.println("Car");
        case 'c':
            System.out.println("Boat");
            break;
   }
   ````
   Copy the code & run it .
   **Question**: The behaviour is called “fall through”. What is happening there?

2. Change the color example from the previous exercise to get the following result:

    ![](images/colorswitch3.png)

    *Use the switch statement with only five break statements. For invalid input, print a message.*

## Converting if to switch
Convert the if statement in the following code into a switch:
````java
Scanner stdin = new Scanner(System.in); 
int choice = 0;

System.out.println("Please enter your choice (1-4): "); 
choice = stdin.nextInt();

if (choice == 1) {
  System.out.println("You selected 1.");
} else if (choice == 2 || choice == 31) {
  System.out.println("You selected 2 or 3.");
} else if (choice == 4) {
  System.out.println("You selected 4.");
} else {
  System.out.printin("Please enter a choice between 1-4");
}

````

## Simple Calculator
Your task is to write a simple calculator that works like this
````
Please enter the first number: 
4
Please enter the second number:
6
Please enter the operator + - * /:
+
Result = 10
````
Rules are:
* Output “Invalid Operator” when the operator is invalid.
* Addion, Subtraction, multiplication and division are supported
* Write a separate method for every calculating operation
* Use a switch statement

## Extraction (Bonus exercise)
We received the following code from our customer:
````java
public class RefactorMe {
    public static void main(String[] args) {
        char input = 'c';
        switch (input) {
            case 'a':
                System.out.println("You pressed 'a'");
                break;
            case 'b':
                System.out.println("You pressed 'b' and here's 10 numbers");
                for (int i = 0; i < 10; i++) {
                    System.out.println(i);
                }
                break;
            case 'c':
                System.out.println("You pressed 'c'");
                System.out.println("The sum of the 10 first numbers is ");
                int sum = 0;
                for (int i = 0; i < 10; i++) {
                    sum = sum + i;
                }
                System.out.println("Sum = " + sum);
                break;
        }
    }
}
````
It is best practice to extract the code from case blocks into separate methods.
````java
switch (input) {
    case 'a':
        handleA();
        break;
    case 'b':
        handleB();
        break;
    case 'c':
        handleC();
        break;
}
````
We can do this refactoring manually or use IntelliJ built in tools.

Perform the refactoring for the code above using these steps:
* Select the code to extract.
* right click -> Choose Refactor -> Extract method (or press Ctrl+Alt+M)
* Enter a name for the new method, e.g. handleB
* Press Ok

## Further Bonus exercises
### Vowels and consonants  
Write a program, which asks the user for a character. Check if the character is a vowel or a consonant.
Additional challenge: Write the switch statement with only one break.

### Months 📅
Write a method with the following signature. The method returns the name of the Month for a month number (1-12). Use a switch statement.

`public String getMonthName(int monthNumber)`

