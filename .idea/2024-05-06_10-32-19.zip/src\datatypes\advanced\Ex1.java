package datatypes.advanced;

public class Ex1 {
    public static void main(String[] args) {
        String example = "THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG";
        StringBuilder output = new StringBuilder();
        int offset = 23;
        for (char c: example.toCharArray()){
            if (c != ' '){
            output.append(shift(c,offset));
            }
            else{
                output.append(' ');
            }
        }


        System.out.println(output);
    }


    public static char shift(char input,int offset) {
        input = (char)((input-65+offset)%26+65);
        return input;
    }
}
