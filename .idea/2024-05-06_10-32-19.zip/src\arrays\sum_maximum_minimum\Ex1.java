package arrays.sum_maximum_minimum;

public class Ex1 {
    public static void main(String[] args) {
        int[] input = new int[]{1, 4, 5, 7, 20000, -511, 100, -200, 400};
        int sum = 0;
        int max = input[0];
        int min = input[0];
        for (int i = 0; i< input.length;i++) {
            sum += input[i];
            if (input[i] > max) max = input[i];
            if (input[i] < min) min = input[i];
        }
        System.out.println("Summe: " + sum);
        System.out.println("Max: " + max);
        System.out.println("Min: " + min);
    }
}
