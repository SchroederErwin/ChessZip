package arrays.play_chess;

public class Game {
    Piece[][] board = new Piece[8][8];
    String turn;
    boolean isGameOver = false;

    //outer array = 8-1 up to down; inner array = A-H left to right
    //initialized board
    public Game() {
        turn = "W";
        String[] outerPieceOrder = new String[]{"R", "N", "B", "Q", "K", "B", "N", "R"}; //white order/ row 1
        for (int i = 0; i < 8; i++) {
            switch (i) {
                case 0:
                    for (int j = 0; j < 8; j++) {
                        board[i][j] = new Piece("B", outerPieceOrder[7 - j], j, i);
                    }
                    break;
                case 1:
                    for (int j = 0; j < 8; j++) {
                        board[i][j] = new Piece("B", "P", j, i);
                    }
                    break;
                case 6:
                    for (int j = 0; j < 8; j++) {
                        board[i][j] = new Piece("W", "P", j, i);
                    }
                    break;
                case 7:
                    for (int j = 0; j < 8; j++) {
                        board[i][j] = new Piece("W", outerPieceOrder[j], j, i);
                    }
                    break;
            }
        }
    }

    void status() {
        System.out.println("  |  A  |  B  |  C  |  D  |  E  |  F  |  G  |  H  |");
        System.out.println("-----------------------------------------------------");
        for (int i = 0; i < 8; i++) {
            System.out.print(8 - i + " | ");
            for (int j = 0; j < 8; j++) {
                if (this.board[i][j] != null) {
                    System.out.print(this.board[i][j].player + "-" + this.board[i][j].type + " | ");
                } else {
                    System.out.print("    | ");
                }

            }
            System.out.println((8 - i) + "\n-----------------------------------------------------");
        }

        System.out.println("  |  A  |  B  |  C  |  D  |  E  |  F  |  G  |  H  |");
        System.out.println();
        System.out.println();
    }

    private boolean isValidMove(int iStart, int jStart, int iEnd, int jEnd) {
        if (iStart < 0 || iEnd < 0 || jStart < 0 || jEnd < 0) {
            return false;
        }
        if (iStart > 7 || iEnd > 7 || jStart > 7 || jEnd > 7) {
            return false;
        }
        //check if there is a piece to start and it's yours
        if (board[iStart][jStart] == null || !board[iStart][jStart].player.equals(turn)) return false;
        //check if you want to go on place where already one of your pieces is placed
        if (board[iEnd][jEnd] != null && board[iEnd][jEnd].player.equals(turn)) return false;

        //check if you move at all
        if (iStart == iEnd && jStart == jEnd) return false;
        switch (board[iStart][jStart].type) {
            case "P":
                return pawnMoves(iStart, jStart, iEnd, jEnd);
            case "R":
                return rookMoves(iStart, jStart, iEnd, jEnd);
            case "N":
                if (((iStart == iEnd + 2 || iStart == iEnd - 2) && (jStart == jEnd + 1 || jStart == jEnd - 1)) //longer side vertical
                        || ((iStart == iEnd + 1 || iStart == iEnd - 1) && (jStart == jEnd + 2 || jStart == jEnd - 2))) { //longer side horizontal
                    return true;
                } else return false;
            case "B":
                return bishopMoves(iStart, jStart, iEnd, jEnd);
            case "Q":
                //combination of rook and bishop
                return (bishopMoves(iStart, jStart, iEnd, jEnd) || rookMoves(iStart, jStart, iEnd, jEnd));
            case "K":
                return kingMoves(iStart, jStart, iEnd, jEnd);
            default:
                return false;
        }

        //check if figure of players turn
        //different for each position
        //check if walking path is taken by nothing your or enemy piece
        //if path is taken (except knight

    }

    static int[] getCoordinates(String input) {
        int iStart = 8 - (input.charAt(1) - 48);
        int iEnd = 8 - (input.charAt(4) - 48);
        int jStart = input.charAt(0) - 65;
        int jEnd = input.charAt(3) - 65;
        int[] coordinates = new int[]{iStart, jStart, iEnd, jEnd};
        return coordinates;
    }

    boolean makeMove(String input) {
        int[] coordinates = getCoordinates(input);
        int iStart = coordinates[0];
        int jStart = coordinates[1];
        int iEnd = coordinates[2];
        int jEnd = coordinates[3];
        if (isValidMove(iStart, jStart, iEnd, jEnd)) {
            //extra rook move when castling
            if (castleCondition(iStart, jStart, iEnd, jEnd)) {
                if (jStart < jEnd) {
                    //bookkeeping position
                    updateLastPosition(iStart, 7);
                    board[iEnd][jEnd - 1] = board[iStart][7];
                    //updating current position
                    updateCurrentPosition(iEnd, jEnd - 1);
                    board[iStart][7] = null;
                } else {
                    updateLastPosition(iStart, 0);
                    board[iEnd][jEnd + 1] = board[iStart][0];
                    updateCurrentPosition(iEnd, jEnd + 1);
                    board[iStart][0] = null;
                }
            } //moving onto King position
            if (board[iEnd][jEnd] != null && board[iEnd][jEnd].type.equals("K")) {
                isGameOver = true;
            }

            updateLastPosition(iStart, jStart);
            board[iEnd][jEnd] = board[iStart][jStart];
            updateCurrentPosition(iEnd, jEnd);
            board[iStart][jStart] = null;
            switchTurn();
            return true;
        }
        return false;


    }

    private void updateCurrentPosition(int y, int x) {
        if (board[y][x] != null) {
            board[y][x].currPositionX = x;
            board[y][x].currPositionY = y;
        }
    }

    void updateLastPosition(int y, int x) {
        if (board[y][x] != null) {
            board[y][x].lastPositionX = board[y][x].currPositionX;
            board[y][x].lastPositionY = board[y][x].currPositionY;
        }
    }




    public void switchTurn() {
        if (this.turn.equals("W")) {
            this.turn = "B";
        } else {
            this.turn = "W";
        }
    }


    //en passant //promotion of pawn //check
    //turn with game won in the end? while loop till legal move or Game Class?

    private boolean rookMoves(int iStart, int jStart, int iEnd, int jEnd) {
        if (iStart != iEnd && jStart == jEnd) { //vertical move
            if (iStart < iEnd) {
                for (int k = iStart + 1; k < iEnd; k++) {
                    if (board[k][jEnd] != null) { //check path
                        return false;
                    }
                }
                return true;
            } else {
                for (int k = iStart - 1; k > iEnd; k--) {
                    if (board[k][jEnd] != null) { //check path
                        return false;
                    }
                }
                return true;
            }

        }
        if (iStart == iEnd && jStart != jEnd) { //horizontal move
            if (jStart < jEnd) {
                for (int k = jStart + 1; k < jEnd; k++) {
                    if (board[iEnd][k] != null) {
                        return false;
                    }
                }
                return true;
            } else {
                for (int k = jStart - 1; k > jEnd; k--) {
                    if (board[iEnd][k] != null) {
                        return false;
                    }
                }
                return true;
            }
        }
        return false;
    }

    private boolean bishopMoves(int iStart, int jStart, int iEnd, int jEnd) {
        if (iStart - iEnd == jStart - jEnd) { //same diagonal topleft-bottomright-movement \
            if (iStart < iEnd) {
                for (int k = 1; k < iEnd - iStart; k++) {
                    if (board[iStart + k][jStart + k] != null) {
                        return false;
                    }
                }
                return true;
            } else {
                for (int k = 1; k < iStart - iEnd; k++) {
                    if (board[iStart - k][jStart - k] != null) {
                        return false;
                    }
                }
                return true;
            }
        } else if (iStart - iEnd == jEnd - jStart) { //same diagonal topright-bottomleft-movement /
            if (iStart < iEnd) {
                for (int k = 1; k < iEnd - iStart; k++) {
                    if (board[iStart + k][jStart - k] != null) {
                        return false;
                    }
                }
                return true;
            } else {
                for (int k = 1; k < iStart - iEnd; k++) {
                    if (board[iStart - k][jStart + k] != null) {
                        return false;
                    }
                }
                return true;
            }
        } else return false;
    }

    private boolean pawnMoves(int iStart, int jStart, int iEnd, int jEnd) {
        if (turn.equals("W")) {
            if (iStart == iEnd + 1 && jStart == jEnd && board[iEnd][jEnd] == null) { //1 Move forward
                return true;
            } else if (iStart == iEnd + 2 && jStart == jEnd && board[iEnd][jEnd] == null //2 Move forward if didnt move yet
                    && board[iStart][jStart].lastPositionX == -1 && board[iStart][jStart].lastPositionY == -1) {
                return true;
            } else
                return iStart == iEnd + 1 && (jStart == jEnd + 1 || jStart == jEnd - 1) && board[iEnd][jEnd] != null; //attack diagonally
        }
        if (turn.equals("B")) {
            if (iStart == iEnd - 1 && jStart == jEnd && board[iEnd][jEnd] == null) { //1 Move forward
                return true;
            } else if (iStart == iEnd - 2 && jStart == jEnd && board[iEnd][jEnd] == null //2 Move forward if didnt move yet
                    && board[iStart][jStart].lastPositionX == -1 && board[iStart][jStart].lastPositionY == -1) {
                return true;
            } else
                return iStart == iEnd - 1 && (jStart == jEnd + 1 || jStart == jEnd - 1) && board[iEnd][jEnd] != null; //attack diagonally
        }
        //track en passant left with last move needed or only track 2 move forward
        return false;
    }

    private boolean kingMoves(int iStart, int jStart, int iEnd, int jEnd) {
        if ((iStart == iEnd + 1 || iStart == iEnd - 1 || iStart == iEnd) && (jStart == jEnd + 1 || jStart == jEnd - 1 || jStart == jEnd)) {
            return true;
            //check for castling //without checking if positioning yourself into check
        } else return (castleCondition(iStart, jStart, iEnd, jEnd));
    }

    public boolean castleCondition(int iStart, int jStart, int iEnd, int jEnd) {
        if ((board[iStart][jStart].lastPositionX == -1) && (board[iStart][jStart].lastPositionY == -1) && (jStart == jEnd + 2 || jStart == jEnd - 2) && (iStart == iEnd)) {
            if ((jStart < jEnd) && (board[iStart][7].type.equals("R")) && (board[iStart][7].lastPositionX == -1) && (board[iStart][7].lastPositionY == -1) && (board[iStart][7].player.equals(this.turn))) { //unmoved rook in the corner
                for (int i = 1; i < 7 - jStart; i++) {
                    if (board[iStart][jStart + i] != null) {
                        return false;
                    }
                }
                return true;
            } else {
                if ((jStart > jEnd) && (board[iStart][0].type.equals("R")) && (board[iStart][0].lastPositionX == -1) && (board[iStart][0].lastPositionY == -1) && (board[iStart][0].player.equals(this.turn))) { //unmoved rook in the corner
                    for (int i = 1; i < jStart; i++) {
                        if (board[iStart][jStart - i] != null) {
                            return false;
                        }
                    }
                    return true;

                }
            }

        }
        return false;
    }
}
