package datatypes.intermediate;

import java.util.Scanner;

public class Exercise2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an integer: ");
        int number = scanner.nextInt();

        int digits = (int) Math.log10(number);
        int sum = 0;

        for (int i = digits; i >= 0; i--) {
            sum += (int) (number/Math.pow(10,i));
            //number -= (Math.floor(number/Math.pow(10,i)))*Math.pow(10,i);
            number = number % (int) Math.pow(10,i);
        }

        System.out.println(sum);
    }
}
