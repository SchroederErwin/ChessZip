# Operators & Datatypes
![](http://www.quickmeme.com/img/70/70f1baf495148492ff11ee3bbdd7f4da7186cfd6d1bbd00402b309d6884a09c8.jpg)
***
## Collection of Exercises 🔨
### Level: Basic ⭐
1. **Incremental Operators**
   1. Run the code and explain the result
      ````java
      int i = 42;
      System.out.println(i);
      System.out.println(i++);
      System.out.println(i);
      System.out.println(++i);
      System.out.println(i);
      ````
   2. What happens in the second line of code?
      ````java
      int j = 42;
      int k = j++ + ++j;
      System.out.println(k);
      ````
2. **Associative Operators**: Rewrite the following code using associative operators
   ````java
   int i = 43;
   i = i + 100;
   i = i - 24;
   i = i * 2;
   i = i / 5;
   System.out.println(i);
   ````
3. **Modulo**
   1. Use the modulo operator to print whether the numbers from 0 to 43 are even or odd.
   2. Which possible values could the expression have if the three question marks are replaced by an arbitrary number?
      ````java
      int j = ???;
      System.out.println(j % 5);
      ````
4. **Relational operators**: Print the following texts depending on the age of a person (stored in an int variable):
   * age is above 60: "You are old"
   * age is above 40: "You are in your 40s or 50s"
   * age is over 20: "You are a young grown-up"
   * age is 20 or less: "You are really young!"
5. **Conditional operators** 
   1. The following Program prints `5,6,7,8,9,10`. Rewrite the if expression using the or operator ( `||` ), so that the output remains the same. Do not use else but use the `!` operator
      ````java
      for(int i = 0; i < 100; i++) {
        if (i >= 5 && i <= 10) {
            System.out.println(i);
        }
      }
      ````
   2. The following program print `5,6,7,8,9,10,42`. Rewrite the program using the `!=` operator instead of the `==` operator. Output must remain the same. Do not use else
      ````java
      for(int i = 0; i < 100; i++) {
        if (i >= 5 && i <= 10 || i == 42) {
            System.out.println(i);
        }
      }
      ````
### Level: Intermediate ⭐⭐
1. Write a program that prompts the user to enter the temperature in Celsius and converts it to Fahrenheit using the formula `F = (9/5)C + 32`.
2. Write a program that takes an `int` as input and outputs the sum of its digits. For example, if the input is `1234`, the output should be 10.
3. Write a program that takes a `double` as input and rounds it to the nearest `int`. (don't use the method of the Java API 😉)
4. Write a program that takes two `int` as input and outputs their sum, difference, product, and quotient.
   **Bonus:** Expand the program to calculate the [gcd](https://en.wikipedia.org/wiki/Greatest_common_divisor)
5. Write a program that takes an `int` as input and outputs its binary representation.
6. Write a program that takes a `String` as input and outputs the number of vowels in the string. For example, if the input is `"Hello World"`, the output should be `3`.

### Level: Advanced (Bonus task) ⭐⭐⭐
*These exercises would also fit into the String submodule - they are only here to prevent anybody of the consultants feeling bored* 😉
1. Implement a solution of the [Caesar chiffre](https://en.wikipedia.org/wiki/Caesar_cipher): Write a method
   which takes a `String` and an offset (`int`) as arguments and shift the single characters of the String by the offset.
2. Expand the previous task to implement the [Vigenère Cipher](https://en.wikipedia.org/wiki/Vigen%C3%A8re_cipher)



