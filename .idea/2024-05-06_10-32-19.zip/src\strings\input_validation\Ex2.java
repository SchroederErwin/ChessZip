package strings.input_validation;

import java.util.Scanner;

public class Ex2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a text to validate: ");
        String input = sc.nextLine();

        //String input = "";
        System.out.println("Checking Rule 1:");
        output(input.length() > 5);

        System.out.println("Checking Rule 2:");
        output(input.length() > 4 && input.length() < 8);

        System.out.println("Checking Rule 3:");
        if (input.length() >0 ) {
            output(Character.isDigit(input.charAt(0)) && Character.isDigit(input.charAt(1)));
        } else {
            output(false);
        }

        System.out.println("Checking Rule 4:");
        output(input.contains("chen"));

        System.out.println("Checking Rule 5:");
        if (input.length() >0 ) {
            output(input.charAt(input.length()-1)==':');
        } else {
            output(false);
        }

        System.out.println("Checking Rule 6:");
        output(input.toUpperCase().equals(input));

        System.out.println("Checking Rule 7:");
        output(input.contains("(") && input.contains(")") && input.indexOf("(")<input.indexOf(")"));
    }

    public static void output(boolean b){
        if (b) {
            System.out.println("OK");
        } else {
            System.out.println("Input Error");
        }
    }
}
