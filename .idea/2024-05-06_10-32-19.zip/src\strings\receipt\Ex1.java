package strings.receipt;

import java.util.Scanner;

public class Ex1 {
    public static void main(String[] args) {
        StringBuilder receipt = new StringBuilder("--- RECEIPT ---\nProduct: ");
        Scanner input = new Scanner(System.in);

        System.out.println("Enter the product name: ");
        receipt.append(input.nextLine()).append("\nPrice per unit: ");

        System.out.println("Price per unit: ");
        int price = input.nextInt();
        receipt.append(price).append("\nQuantity bought: ");

        System.out.println("Quantity bought: ");
        int quantity = input.nextInt();
        int total = price * quantity;
        receipt.append(quantity).append("\nTotal amount to pay, excluding tax: ").append(total).append(" Euro\nTotal amount to pay, including tax: ");

        System.out.println("Food? (y / n): ");
        boolean food = input.next().equalsIgnoreCase("y"); //technically possible to type anything to get false
        double tax = (food ? Math.round(total*107)/100.0 : Math.round(total*119)/100.0);
        receipt.append(tax).append(" Euro\nOf which is tax: ").append(Math.round((tax-total)*100)/100.0).append(" Euro").append("\n----------------\n");







        System.out.println(receipt);
    }
}
