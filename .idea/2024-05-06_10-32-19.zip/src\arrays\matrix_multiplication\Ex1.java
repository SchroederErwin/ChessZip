package arrays.matrix_multiplication;

public class Ex1 {
    public static void main(String[] args) {
        int[][] m1 = { {3, 2, 1}, {1, 0, 2} };
        int[][] m2 = { {1, 2}, {0, 1}, {4, 0} };
        // result should be 7 8
        //                  9 2

        System.out.println("M1:");
        printMatrice(m1);
        System.out.println("M2:");
        printMatrice(m2);
        int[][] result = matrixMultiply(m1, m2);
        System.out.println("M1 x M2 = ");
        printMatrice(result);
    }

    /**Multiplies two matrices if rowlength of first matrix matches column length of second matrix
     *
     * @param m1 first matrix int[][]
     * @param m2 second matrix int[][]
     * @return
     */
    private static int[][] matrixMultiply(int[][] m1, int[][] m2) {
        int[][] result = new int[m1.length][m2[0].length];
        if (m1[0].length == m2.length) {    //rowsize of m1 needs to match columnsize m2
                                            // inner array = column number and rowsize
                                            // outer array = row number and columnsize

            for (int i = 0; i < m1.length; i++) {           //i = rownumber m1   //doesnt need to match j
                for (int j = 0; j < m2[0].length; j++) {    //j = columnnumber m2
                    for (int k = 0; k < m1[0].length; k++) {//k = columnnumber m1 and rownumber m2
                        result[i][j] += m1[i][k] * m2[k][j];      //row m1*column m2
                    }
                }
            }

        }



    return result;
    }

    private static void printMatrice(int[][] m) {
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[i].length; j++) {
                System.out.print(m[i][j] + " ");
            }
            System.out.println();
        }
    }
}
