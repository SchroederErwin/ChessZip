package datatypes.intermediate;

import java.util.Scanner;

public class Exercise1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter temperature in Celcius: ");
        double temperature = scanner.nextDouble();
        System.out.println("Thats " + (temperature*9/5+32) + "° in Fahrenheit.");
    }
}
