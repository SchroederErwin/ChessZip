package arrays.roman_number_conversion;

import java.util.Scanner;

public class Ex1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an integer between 1 and 3999: ");
        int num = scanner.nextInt();
        String romanNum = intToRoman(num);
        System.out.println(num + " in Roman numerals is " + romanNum);
    }

    /**
     * Convert integer number to roman number
     * @param num integer from 1 to 3999
     * @return
     */
    public static String intToRoman(int num) {
        String[] romanSymbols = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
        int[] romanValues =     {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        String roman = "";
        for (int i = 0; i < romanValues.length; i++) {
            while (num >= romanValues[i]) {     //check if roman number still fits into our number
                num -= romanValues[i];
                roman += romanSymbols[i];       //add to String
            }
        }


        return roman;
    }
}
