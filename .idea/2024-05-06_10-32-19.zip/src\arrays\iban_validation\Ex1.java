package arrays.iban_validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Ex1 {
    public static void main(String[] args) {
        String testIBANValid   = "DE23 6005 0101 1111 2222 33"; // "DE65 100 400 600 100 400 600";
        String testIBANInvalid = "DE12 345 678 910 234 567 89";

        System.out.println(testIBANInvalid + " is valid? " + validateIBAN(testIBANInvalid));
        System.out.println(testIBANValid + " is valid? " + validateIBAN(testIBANValid));
    }
    public static boolean validateIBAN(String IBAN) {

        //600501011111222233131423L //long not enough
        String[] numbers = new String[8];
        Pattern pattern = Pattern.compile("([A-Z]{2})(\\d{2})\\D?(\\d{4})\\D?(\\d{4})\\D?(\\d{4})\\D?(\\d{4})\\D?(\\d{2})");
        Matcher matcher = pattern.matcher(IBAN);
        int index = 0;
        while (matcher.find()) {
            String initials = matcher.group(1);
            //convert letter with -64+9 and put all 4 at the end but before checksum
            for (int i = 0; i < 2; i++) {
                numbers[numbers.length-3+i] = Integer.toString(initials.charAt(i)-64+9);
            }
            //front 0 lost when using int[]
            numbers[numbers.length-1] = matcher.group(2); // first 2 numbers (checksum) placed at end
            numbers[index++] = matcher.group(3);
            numbers[index++] = matcher.group(4);
            numbers[index++] = matcher.group(5);
            numbers[index++] = matcher.group(6);
            numbers[index++] = matcher.group(7);
        }

        int temp = 0;
        for (String num : numbers){
            if (num != null){
                temp = (temp*(int)Math.pow(10,num.length()) + Integer.parseInt(num))%97;  //concatenate temp and next number.
                                                                                          // Since temp is multiplied with amount of digits of num no prefix 0 is lost.
            }
        }
        return (temp == 1);
    }
}
