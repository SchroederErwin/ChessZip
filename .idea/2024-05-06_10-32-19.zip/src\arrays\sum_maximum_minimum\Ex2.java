package arrays.sum_maximum_minimum;

public class Ex2 {
    public static void main(String[] args) {
        int[] input = new int[]{1, 4, 5, 7, 20000, -511, 100, -200, 400};
        int sum = 0;
        int max = input[0];
        int min = input[0];
        for (int number : input) {
            sum += number;
            if (number > max) max = number;
            if (number < min) min = number;
        }
        System.out.println("Summe: " + sum);
        System.out.println("Max: " + max);
        System.out.println("Min: " + min);
    }
}
