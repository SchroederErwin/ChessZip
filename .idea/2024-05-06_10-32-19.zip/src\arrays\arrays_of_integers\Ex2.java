package arrays.arrays_of_integers;

public class Ex2 {
    public static void main(String[] args) {
        int[] orignal = new int[]{1, 2, 3, 4 ,5};
        int[] shifted = new int[orignal.length];
        int offset = 2;
        for (int i = 0; i < orignal.length; i++) {
            shifted[(i+offset)% orignal.length] = orignal[i];
        }
        for (int num : shifted) {
            System.out.print(num + " ");
        }

    }
}
