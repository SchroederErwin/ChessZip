package datatypes.intermediate;

import java.util.Scanner;

public class Exercise3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a decimal value: ");
        double a = scanner.nextDouble(); // local digit seperator
        int out;
        if (a > 0){
            out = (int) (a + 0.5);
        } else {
            out = (int) (a - 0.5);
        }
        System.out.println(out);
    }
}
