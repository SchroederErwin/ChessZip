package strings.input_validation;

import java.util.Scanner;

public class Ex1 {
    public static void main(String[] args) {
//        String input = "ThisIsAVeryLongTest"; //replace by scanner after testing
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a small text: ");
        String input = sc.nextLine();
        if (input.length()<11) {
            System.out.println("OK");
        } else {
            System.out.println("Input Error");
        }


    }
}
