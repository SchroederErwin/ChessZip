package strings.ascii_table;

public class Ex1 {
    public static void main(String[] args) {
        for (int i = 0; i < 32;i++) {
            System.out.println  (i + " " + Integer.toHexString(i) + " " + (char)i + "\t\t" +
                                (i+32) + " " + Integer.toHexString(i+32) + " " + (char)(i+32) + "\t\t" +
                                (i+64) + " " + Integer.toHexString(i+64) + " " + (char)(i+64) + "\t\t" +
                                (i+96) + " " + Integer.toHexString(i+96) + " " + (char)(i+96));

        } //8 Backspace 9 Tab 10 Line feed 13 carriage return
    }
}
