package arrays.arrays_of_integers;

import java.util.Arrays;

public class Ex1 {
    public static void main(String[] args) {
        int[] input = new int[]{1, 4, 5, 7, 20000, -511, 100, -200, 400};
        int sum = 0;
        for (int number : input) {
            sum += number;
        }
        double average = (double)sum / input.length;
        //sorting array to be able to pull the middle value
        bubbleSort(input);
        double median;
        if (input.length%2 == 1) {
            //value in the middle
            median = input[input.length/2];
        } else {
            //average value between both middle values
            median = input[input.length/2-1]+input[input.length/2];
        }
        System.out.printf("average/mean: \t%.2f \nmedian: \t\t%.2f\n",average, median);

    }

    /**
     * sorts integer array  in-place in ascending order
     * @param input integer array which get sorted
     */
    private static void bubbleSort(int[] input) {
        for (int i = 0; i < input.length - 1; i++) {
            for (int j = 0; j < input.length - i - 1; j++) {
                if (input[j] > input[j + 1]) {
                    int tmp = input[j];
                    input[j] = input[j + 1];
                    input[j + 1] = tmp;
                }
            }
        }
    }
}
