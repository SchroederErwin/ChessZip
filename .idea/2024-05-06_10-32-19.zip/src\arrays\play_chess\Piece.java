package arrays.play_chess;

public class Piece {
    String player; //owned by which player
    String type;
    int currPositionX;
    int currPositionY;
    int lastPositionX; //needed for castling
    int lastPositionY;

    public Piece(String player, String type,int currPositionX, int currPositionY) {
        this.player = player;
        this.type = type;
        this.currPositionX = currPositionX;
        this.currPositionY = currPositionY;
        this.lastPositionX = -1;
        this.lastPositionY = -1;
    }

    public int getLastPositionY() {
        return lastPositionY;
    }

    public void setLastPositionY(int lastPositionY) {
        this.lastPositionY = lastPositionY;
    }

    public int getLastPositionX() {
        return lastPositionX;
    }

    public void setLastPositionX(int lastPositionX) {
        this.lastPositionX = lastPositionX;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPlayer() {
        return player;
    }

    public void setPlayer(String player) {
        this.player = player;
    }


}
