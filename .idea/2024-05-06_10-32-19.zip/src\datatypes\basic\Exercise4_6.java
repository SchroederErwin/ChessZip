package datatypes.basic;

public class Exercise4_6 {
    public static void main(String[] args) {
        System.out.println("---------------");
        System.out.println("Basic 4:");

        int age = 50;
        if (age > 60) {
            System.out.println("You are old");
        } else if (age > 40) {
            System.out.println("You are in your 40s or 50s");
        } else if (age > 20) {
            System.out.println("You are a young grown-up");
        } else {
            System.out.println("You are really young!"); // assuming valid input
        }


        System.out.println("---------------");
        System.out.println("Basic 5i:");
        for(int i = 0; i < 100; i++) {
            if (!((i<5) || (i > 10))) {
                System.out.println(i);
            }
        }
        System.out.println("---------------");
        System.out.println("Basic 5ii:");
        for(int i = 0; i < 100; i++) {
            if (!(i < 5 || i > 10 && i != 42)) {
                System.out.println(i);
            }
        }
    }
}
